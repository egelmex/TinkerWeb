Run like this:
> furby.jar -jar <audio_file.wav> <data1> <COM_PORT> [<dataN> <COM_PORT> ..]

The data we used can be found in the data folder. 
.wav files are omitted for copy right reasons, but youtube might be a good place to look ;)