import com.sun.xml.internal.ws.util.ByteArrayBuffer;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.File;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.UnsupportedAudioFileException;


public class MusicPreloader { 
    private final ByteArrayInputStream preloaded;
    private final SourceDataLine sourceDataLine;
    private final AudioFormat format;
    
    public MusicPreloader(String audioFile) throws IOException, UnsupportedAudioFileException, LineUnavailableException {
        this(new File(audioFile));
    }
    
    public MusicPreloader(File audioFile) throws IOException, UnsupportedAudioFileException, LineUnavailableException {
        try(ByteArrayBuffer buff = new ByteArrayBuffer(); AudioInputStream in = AudioSystem.getAudioInputStream(audioFile)) {
            format = in.getFormat();
            byte[] array = new byte[1024];
            while( in.read(array, 0, 1024)>=0 ) {
                buff.write(array);
            }
            preloaded = new ByteArrayInputStream(buff.getRawData());
            
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
            sourceDataLine = (SourceDataLine) AudioSystem.getLine(info);
            sourceDataLine.open(format);
        }
    }
    
    public void play() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final int size = format.getFrameSize()*2;
                byte[] array = new byte[size];
                sourceDataLine.start();
                while(preloaded.available()>0) {
                    int read = preloaded.read(array, 0, size);
                    sourceDataLine.write(array, 0, read);
                }
                sourceDataLine.drain();
                sourceDataLine.stop();
            }
        }).start();
    }
}
