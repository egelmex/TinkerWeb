import gnu.io.*;
import java.io.IOException;

import java.io.OutputStream;

public class TwoWaySerialComm implements CommChannel {
    
    private final OutputStream out;

    public TwoWaySerialComm( String portName ) throws NoSuchPortException, UnsupportedCommOperationException, PortInUseException, IOException {
        CommPortIdentifier portIdentifier = CommPortIdentifier.getPortIdentifier(portName);
        CommPort commPort = portIdentifier.open(this.getClass().getName(),2000);

        if (commPort instanceof SerialPort) {
            SerialPort serialPort = (SerialPort) commPort;
            serialPort.setSerialPortParams(57600,SerialPort.DATABITS_8,SerialPort.STOPBITS_1,SerialPort.PARITY_NONE);
            out = serialPort.getOutputStream();
        } else {
            throw new UnsupportedCommOperationException();
        }
    }
    
    @Override
    public void sendCommand(byte cmd) throws IOException {
        out.write(cmd);
        out.flush();
    }
}