
import gnu.io.NoSuchPortException;
import gnu.io.PortInUseException;
import gnu.io.UnsupportedCommOperationException;
import java.io.IOException;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kg246
 */
public interface CommChannel {
    
    void sendCommand(byte command) throws IOException;
    
    /**
     * A Dummy serial class which outputs to stdout instead of a serial device
     */
    public static class Dummy implements CommChannel {
        private final String port;
        
        public Dummy(String port) throws NoSuchPortException,
                UnsupportedCommOperationException,
                PortInUseException, IOException {
            this.port = port;
        }
        
        @Override
        public void sendCommand(byte command) throws IOException {
            synchronized(System.out) {
                System.out.print(port);
                System.out.print(": ");
                System.out.println(command);
            }
        }

        @Override
        public String toString() {
            return port;
        }
    }
    
}
