import gnu.io.NoSuchPortException;
import gnu.io.PortInUseException;
import gnu.io.UnsupportedCommOperationException;
import java.io.*;
import java.util.StringTokenizer;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 * Write a description of class Control here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FurbyController {
    
    private static final int THREADS = 2;
    private static final long INITAL_MILIIS_DELAY = 5000L; //Pause for Furby reset
    private static final long AUDIO_DELAY = 15L; //Delay audio for comm sync.
    
    public static void main(String[] args) {
        
        if(args.length==0 || args[0].equals("-h")) {
            System.out.println("java -jar <jar file> <wav file> [-d] [<csv> <port>]+");
            System.exit(0);
        }
        
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(THREADS);
        MusicPreloader m = null;
        try {
            System.out.println("Preloading Audio");
            m = new MusicPreloader(args[0]);
            System.out.println("Preload complete.");
        } catch (IOException | UnsupportedAudioFileException | LineUnavailableException ex) {
            System.err.println("Audio Failed to load");
            ex.printStackTrace();
        }
        final MusicPreloader music = m;
        
        try {
            System.out.println("Loading Furby Data");
            int i;
            boolean dummyMode;
            if(args[1].equals("-d")) {
                i=2;
                dummyMode = true;
            } else {
                i=1;
                dummyMode = false;
            }
            while(i<args.length) {
                CommChannel comm = dummyMode ? new CommChannel.Dummy(args[i+1]) : new TwoWaySerialComm(args[i+1]);
                loadToExecutor(new File(args[i]), executor, comm, INITAL_MILIIS_DELAY);
                i+=2;
            }
            System.out.println("Load Complete");
        } catch (NoSuchPortException | UnsupportedCommOperationException | PortInUseException | IOException ex) {
            ex.printStackTrace();
        }
        
        executor.schedule(new Callable<Void>() {
            @Override
            public Void call() throws IOException {
                music.play();
                return null;
            }
        }, INITAL_MILIIS_DELAY+AUDIO_DELAY, TimeUnit.MILLISECONDS);
        
        //TODO:
        //executor.awaitTermination(10,TimeUnit.MINUTES);
        //executor.shutdown();
    }
    
    private static final long AUTO_HOMING_INTERVAL = 5000L;
    private static final long AUTO_HOMING_DELAY = 100L;
    
    public static void loadToExecutor(File csv, ScheduledExecutorService executor, CommChannel comm, long timeOffset) {
        long prev = 0L;
        try(BufferedReader in = new BufferedReader(new FileReader(csv))) {
            String line;
            while( (line=in.readLine())!=null ) {
                StringTokenizer st = new StringTokenizer(line, ",");
                long time = timeOffset + Long.parseLong(st.nextToken());
                byte command = Byte.parseByte(st.nextToken());
                executor.schedule(new FurbyAction(command,comm), time, TimeUnit.MILLISECONDS);
                if(time>=prev+AUTO_HOMING_INTERVAL) {
                    executor.schedule(new FurbyAction((byte)0,comm), prev+AUTO_HOMING_DELAY, TimeUnit.MILLISECONDS);
//                    System.out.print("Auto-Homing Command added at ");
//                    System.out.print(time+AUTO_HOMING_DELAY);
//                    System.out.print(" to channel ");
//                    System.out.println(comm);
                }
                prev = time;
            }
        } catch (IOException ex) {
            System.err.println("Failed to read from CSV: "+csv.getAbsolutePath());
            ex.printStackTrace();
        }
    }
}
