
import java.io.IOException;
import java.util.concurrent.Callable;

/**
 * Furby action class is used to store the command and will be called at
 * it's respective time
 * @author kg246
 */
public class FurbyAction implements Callable<Void> {
    private final byte command;
    private final CommChannel comm;
    
    public FurbyAction(byte command, CommChannel comm) {
        this.command = command;
        this.comm = comm;
    }

    @Override
    public Void call() throws IOException {
        comm.sendCommand(command);
        return null;
    }
    
    
}
